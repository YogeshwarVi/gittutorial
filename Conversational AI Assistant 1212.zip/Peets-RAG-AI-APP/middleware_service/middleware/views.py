# views.py

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import ChatHistory
import requests
import json


@csrf_exempt
def chat(request):
    return render(request, 'index.html')

@csrf_exempt
def invoke(request):
    print(request)
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        user_id = data['input']['user_id']
        question = data['input']['question']
        print('user_id:',user_id )
        print('question:',question )

        # Fetch chat history for the user
        past_chat_history = list(ChatHistory.objects.filter(user_id=user_id).order_by('-id')[:5].values('question', 'response'))
        print(past_chat_history)

        # Call the AI service
        response = call_main_script(question, past_chat_history)

        # Save the conversation to the database
        ChatHistory(user_id=user_id, question=question, response=response).save()

        return JsonResponse({'response': response})
    else:
        return JsonResponse({'error': 'Invalid request method'})


def call_main_script(question, past_chat_history):
    inputs = {"input":{"chat_history": past_chat_history, "question": question}}
    response = requests.post("http://host.docker.internal:8008/chat/invoke/", json=dict(inputs))
    print(response)
    return response.json()['output']

