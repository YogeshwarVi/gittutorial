# models.py
from django.db import models

class ChatHistory(models.Model):
    user_id = models.CharField(max_length=50)
    question = models.TextField()
    response = models.TextField()

    # Add any additional fields needed, like timestamps

    def __str__(self):
        return f"User: {self.user_id}, Question: {self.question}"
