#!/usr/bin/env python
"""Example LangChain server exposes a conversational retrieval chain."""
import asyncio
import os
from operator import itemgetter
from typing import List, Optional, Sequence, Tuple, Union, Dict
import os
import openai

from dotenv import find_dotenv, load_dotenv
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma

from fastapi import FastAPI
from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder, PromptTemplate
from langchain.pydantic_v1 import BaseModel, Field
from langchain.chat_models import ChatOpenAI
from langserve import add_routes

from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware

from langchain.schema.language_model import BaseLanguageModel
from langchain.schema.messages import AIMessage, HumanMessage
from langchain.schema.output_parser import StrOutputParser
from langchain.schema.retriever import BaseRetriever
from langchain.schema.runnable import (
    Runnable,
    RunnableBranch,
    RunnableLambda,
    RunnableMap,
)


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

import sqlite3
from fastapi import HTTPException

load_dotenv(find_dotenv())

openai.api_key = os.getenv("OPENAI_API_KEY")

os.environ['OPENAI_API_KEY'] = openai.api_key



RESPONSE_TEMPLATE = """You are an expert knowledge base retrieval chatbot,tasked with answering questions from documents.\
If there is nothing in the context relevant to the question at hand, just say\
"Hmm, I'm not sure." Don't try to make up an answer."""

REPHRASE_TEMPLATE = """\
Given the following conversation and a follow up question, rephrase the follow up \
question to be a standalone question.

Chat History:
{chat_history}
Follow Up Input: {question}
Standalone Question:"""


# User input
class ChatRequest(BaseModel):
    """Chat history with the bot."""

    chat_history: Optional[List[Dict[str, str]]]
    question: str


def get_retriever():
    embeddings = OpenAIEmbeddings(model='text-embedding-ada-002',openai_api_key=openai.api_key)
    docsearch = Chroma(persist_directory="./chroma_db", embedding_function=embeddings)
    retriever = docsearch.as_retriever()
    return retriever

def create_retriever(
    llm: BaseLanguageModel, retriever: BaseRetriever
) -> Runnable:
    CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template(REPHRASE_TEMPLATE)
    condense_question_chain = (
        CONDENSE_QUESTION_PROMPT | llm | StrOutputParser()
    ).with_config(
        run_name="CondenseQuestion"
    )

    conversation_chain = condense_question_chain | retriever

    return RunnableBranch(
        (
            RunnableLambda(lambda x: bool(x.get("chat_history"))).with_config(
                run_name="HasChatHistoryCheck"
            ),
            conversation_chain.with_config(run_name="RetrievalChainWithHistory"),
        ),
        (
            RunnableLambda(itemgetter("question")).with_config(
                run_name="Itemgetter:question"
            )
            | retriever
        ).with_config(run_name="RetrievalChainWithNoHistory"),
    ).with_config(run_name="RouteDependingOnChatHistory")

def serialize_history(request: ChatRequest):
    chat_history = request["chat_history"] or []
    converted_chat_history = []
    for message in chat_history:
        if message.get("human") is not None:
            converted_chat_history.append(HumanMessage(content=message["human"]))
        if message.get("ai") is not None:
            converted_chat_history.append(AIMessage(content=message["ai"]))
    return converted_chat_history


def create_chain(llm: BaseLanguageModel, retriever: BaseRetriever) -> Runnable:
    retriever_chain = create_retriever(llm, retriever)
    _context = RunnableMap(
        {
            "context": retriever_chain.with_config(run_name="RetrievalChain"),
            "question": RunnableLambda(itemgetter("question")),
            "chat_history": RunnableLambda(itemgetter("chat_history")),
        }
    )

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", RESPONSE_TEMPLATE),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{question}"),
        ]
    )

    response_synthesizer = (prompt | llm | StrOutputParser()).with_config(
        run_name="GenerateResponse",
    )

    # Runnable to store history on the fly
    # store_history_on_fly = RunnableLambda(
    #     lambda x: chat_history_queue.append((x.get("question", ""), x.get("response", "")))
    # ).with_config(run_name="StoreHistoryOnFly")

    return (
        {
            "question": RunnableLambda(itemgetter("question")).with_config(
                run_name="Itemgetter:question"
            ),
            "chat_history": RunnableLambda(serialize_history).with_config(
                run_name="SerializeHistory"
            ),
        }
        | _context
        | response_synthesizer 
    )


llm = ChatOpenAI(
    model="gpt-3.5-turbo",
    # model="gpt-4",
    streaming=False,
    temperature=0,
)


retriever = get_retriever()

chain = create_chain(llm, retriever)

add_routes(
    app, chain, path="/chat", input_type=ChatRequest
)

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(app, host="localhost", port=8008)