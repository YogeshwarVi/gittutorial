from dotenv import find_dotenv, load_dotenv
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import DirectoryLoader
import os, openai
# Import necessary modules
import sqlite3
from fastapi import HTTPException

load_dotenv(find_dotenv())

openai.api_key = os.getenv("OPENAI_API_KEY")

os.environ['OPENAI_API_KEY'] = openai.api_key
print(os.listdir())
loader = DirectoryLoader('Docs/', glob='**/*.pdf')
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)

embeddings = OpenAIEmbeddings(model='text-embedding-ada-002',openai_api_key=openai.api_key)
Chroma.from_documents(texts, embeddings, persist_directory="./chroma_db")


# # Database initialization and connection
# DATABASE_NAME = "chat_history.db"

# def init_database():
#     conn = sqlite3.connect(DATABASE_NAME)
#     cursor = conn.cursor()

#     # Create a table to store chat history
#     cursor.execute('''
#         CREATE TABLE IF NOT EXISTS chat_history (
#             id INTEGER PRIMARY KEY AUTOINCREMENT,
#             user_id INTEGER,
#             question TEXT,
#             response TEXT
#         )
#     ''')

#     conn.commit()
#     conn.close()

# init_database()