from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from questions.models import Question
from questions.serializers import QuestionSerializer
from django.utils.crypto import get_random_string
from django.template.defaultfilters import slugify


def helloworld(request):
    template = loader.get_template('helloworld.html')
    return HttpResponse(template.render())

class HelloView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        content = {'message': 'Hello, World! from here222'}
        return Response(content)

class QuestionsView(APIView):
    #permission_classes = (IsAuthenticated,)
    def get(self, request):
        content = Question.objects.all().values()
        return Response(content)
    def post(self, request):
        #request.query_params, request.data
        #return Response(request.data)
        question = Question(question=request.data.get('question'), user=request.data.get('user'),slug=slugify(request.data.get('question'))+'-'+get_random_string(length=8))
        question.save()

        questionobj = Question.objects.get(id=question.id)
        questionobj.answer = request.data.get('question')+"Test Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
        questionobj.save()

        m = Question.objects.get(id=question.id) #Question.objects.filter(id=15).all()
        serializer = QuestionSerializer(m)
        response = {
            'data' : serializer.data,
            'status' : status.HTTP_200_OK
        }
        return Response(response)
        #return Response(Question.objects.filter(id=15).values())
        #return Response(Question.objects.filter(id=question.id).values())
        #return Response(request.data)    