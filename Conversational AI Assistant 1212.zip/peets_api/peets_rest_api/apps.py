from django.apps import AppConfig


class PeetsRestApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'peets_rest_api'
