from django.http import HttpResponse
from django.template import loader
from .models import Question

def questions(request):
  myquestions = Question.objects.all().values()
  template = loader.get_template('all_questions.html')
  context = {
    'myquestions': myquestions,
  }
  return HttpResponse(template.render(context, request))

def details(request, slug):
  myquestion = Question.objects.get(slug=slug)
  template = loader.get_template('details.html')
  context = {
    'myquestion': myquestion,
  }
  return HttpResponse(template.render(context, request))

def main(request):
  template = loader.get_template('main.html')
  return HttpResponse(template.render())

def testing(request):
  template = loader.get_template('testing.html')
  context = {
    'fruits': ['Apple', 'Banana', 'Cherry'],   
  }
  return HttpResponse(template.render(context, request))