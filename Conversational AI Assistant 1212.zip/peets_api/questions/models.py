from django.db import models

class Question(models.Model):
  question = models.CharField(max_length = 512)
  answer = models.TextField(null=True)
  user = models.IntegerField(null=True)
  created_at = models.DateTimeField(auto_now_add=True)
  slug = models.SlugField(default="", null=False)
  def __str__(self):
    return f"{self.question}"